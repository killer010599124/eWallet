{
    'name': 'React Native',
    'version': '1.0',
    'summary': 'This module is associated with react native app',
    'description': 'This module is associated with react native app',
    'author': 'night fury',
    'website': 'https://www.yourwebsite.com',
    'category': 'api',
    'depends': [],
    'data': [
        # List of XML files that define data records to be loaded when the module is installed
    ],
    'demo': [
        # List of XML files that define demo data records (used for demonstration purposes)
    ],
    'installable': True,
    'auto_install': False,
}