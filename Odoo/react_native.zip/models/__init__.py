# -*- coding: utf-8 -*-

from . import rating
# from . import product
# from . import product_strategy
